Version : 1.0

-------------How Install-------------
Drag & Drop *mzp file in 3ds max viewport and hit >install< button.
Go to Customize -> Customize User Interface, choose "DmitryG Tools" in the Category list and use it!
----------------------------------------------------------------------------------------------------

-------------How UnInstall-------------
Drag & Drop *mzp file in 3ds max viewport and hit >Uninstall All< button.
----------------------------------------------------------------------------------------------------

Guide - https://youtu.be/bt6lz7Q6XYc
Gumroad - https://gumroad.com/dmitry_gubkin
Portfolio - https://www.artstation.com/dmitry_g
